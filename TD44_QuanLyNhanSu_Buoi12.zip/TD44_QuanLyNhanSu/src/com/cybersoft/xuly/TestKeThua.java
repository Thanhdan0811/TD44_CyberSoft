package com.cybersoft.xuly;

import com.cybersoft.quanlynhansu.NhanSu;

public class TestKeThua extends NhanSu {
	public void testDefault() {
		hoTen = "Tuan";
	}

	@Override
	public double tinhPhuCap() {
		// TODO Auto-generated method stub
		return 0;
	}
}
